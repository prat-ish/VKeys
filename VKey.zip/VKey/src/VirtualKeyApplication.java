
public class VirtualKeyApplication {

	 public static void main(String[] args) {
	    	
	    	WelcomeScreen welcome = new WelcomeScreen();
	    	welcome.intro();
	    	welcome.getInput();

	    }
	
}
